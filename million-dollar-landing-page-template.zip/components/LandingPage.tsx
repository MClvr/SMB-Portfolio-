
import React from 'react';
import { 
  CheckCircle, 
  ArrowRight, 
  Star, 
  Rocket, 
  ShieldCheck, 
  Target, 
  Zap,
  Menu,
  Clock
} from 'lucide-react';

const LandingPage: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* NAVIGATION */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
                B
              </div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900">
                BLUEPRINT<span className="text-indigo-600">PRO</span>
              </span>
              {/* <!-- BLUEPRINT COMMENT: Insert your brand name here. Aim for something that conveys authority. --> */}
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#benefits" className="text-slate-600 hover:text-indigo-600 font-medium transition-colors">Benefits</a>
              <a href="#proof" className="text-slate-600 hover:text-indigo-600 font-medium transition-colors">Results</a>
              <button className="bg-indigo-600 text-white px-6 py-2.5 rounded-full font-bold hover:bg-indigo-700 transition-all hover-lift shadow-lg shadow-indigo-200">
                Book Now
              </button>
              {/* <!-- BLUEPRINT COMMENT: Your primary CTA should always be visible and high contrast. --> */}
            </div>
            
            <div className="md:hidden">
              <Menu className="w-6 h-6 text-slate-600" />
            </div>
          </div>
        </div>
      </nav>

      {/* HERO SECTION - THE OUTCOME */}
      <header className="relative pt-20 pb-16 lg:pt-32 lg:pb-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
            <div className="mb-12 lg:mb-0">
              <span className="inline-block py-1 px-4 rounded-full bg-indigo-50 text-indigo-700 text-sm font-bold tracking-wide uppercase mb-6">
                Limited to the first 10 clients this month
              </span>
              <h1 className="text-5xl lg:text-7xl font-extrabold text-slate-900 leading-[1.1] mb-8">
                Achieve Your <span className="text-indigo-600">Dream Outcome</span> Without The Typical Hassle.
                {/* <!-- BLUEPRINT COMMENT: HERO HEADLINE - Focus on the 'Delight' or 'Result'. What is the #1 transformation? --> */}
              </h1>
              <p className="text-xl text-slate-600 mb-10 leading-relaxed max-w-xl">
                Imagine waking up every day knowing that your biggest challenge is finally solved. We help you transition from where you are to where you deserve to be.
                {/* <!-- BLUEPRINT COMMENT: HERO SUBHEAD - Emphasize the emotional transition. --> */}
              </p>
              
              <ul className="space-y-4 mb-10">
                {[
                  "Emotional Benefit: No more stressful weekends worrying about growth.",
                  "Time Benefit: Reclaim 15+ hours every single week.",
                  "Status Benefit: Become the recognized leader in your specific industry."
                ].map((bullet, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-700 font-medium">
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                    <span>{bullet}</span>
                    {/* <!-- BLUEPRINT COMMENT: 3 EMOTIONAL BULLETS - Hit different pain points and desires. --> */}
                  </li>
                ))}
              </ul>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-indigo-600 text-white px-8 py-4 rounded-2xl text-lg font-bold transition-all hover-lift cta-pulse shadow-xl shadow-indigo-300 flex items-center justify-center gap-2">
                  Get Started Now <ArrowRight className="w-5 h-5" />
                </button>
                <p className="flex items-center justify-center text-sm text-slate-500 sm:max-w-[200px] text-center sm:text-left">
                  Join 1,200+ achievers who took this step.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="absolute -top-10 -right-10 w-64 h-64 bg-indigo-100 rounded-full blur-3xl opacity-50"></div>
              <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-blue-100 rounded-full blur-3xl opacity-50"></div>
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop" 
                alt="Transformation Success" 
                className="relative z-10 rounded-3xl shadow-2xl border border-white"
              />
              {/* <!-- BLUEPRINT COMMENT: High-quality image showing people in their 'post-success' state. --> */}
            </div>
          </div>
        </div>
      </header>

      {/* THE "SO THAT" GRID */}
      <section id="benefits" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-extrabold text-slate-900 mb-4">
              Why Choose Our Unique Methodology?
              {/* <!-- BLUEPRINT COMMENT: Benefits Section Title - Focus on 'Why Us'. --> */}
            </h2>
            <p className="text-lg text-slate-500 max-w-2xl mx-auto">
              We don't just provide a service; we provide a structural shift in how you operate.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                icon: <Target className="w-8 h-8 text-indigo-600" />,
                title: "Precision Strategic Alignment",
                description: "We align your daily actions with your long-term goals **so that** you never waste another minute on low-impact tasks."
              },
              {
                icon: <Zap className="w-8 h-8 text-indigo-600" />,
                title: "Automated Workflow Engine",
                description: "We build systems that work while you sleep **so that** you can scale your revenue without scaling your stress level."
              },
              {
                icon: <ShieldCheck className="w-8 h-8 text-indigo-600" />,
                title: "Guaranteed Outcome Shield",
                description: "We back every project with a 100% satisfaction promise **so that** you have zero risk and maximum peace of mind."
              },
              {
                icon: <Rocket className="w-8 h-8 text-indigo-600" />,
                title: "Hyper-Growth Launchpad",
                description: "Access our network of elite industry partners **so that** you can bypass years of networking and get straight to the top."
              }
            ].map((item, i) => (
              <div key={i} className="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:border-indigo-200 transition-colors group">
                <div className="mb-6 p-3 bg-white w-fit rounded-2xl shadow-sm group-hover:shadow-md transition-shadow">
                  {item.icon}
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">{item.title}</h3>
                <p className="text-slate-600 leading-relaxed">
                  {item.description}
                </p>
                {/* <!-- BLUEPRINT COMMENT: The 'So That' description is critical. Every feature must lead to a specific human benefit. --> */}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section id="proof" className="py-24 bg-slate-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-8">
            <div>
              <p className="text-indigo-600 font-bold tracking-widest uppercase text-sm mb-4">The Trust Line</p>
              <h2 className="text-3xl lg:text-5xl font-extrabold text-slate-900">
                Trusted by 450+ industry leaders globally.
                {/* <!-- BLUEPRINT COMMENT: Trust Line - Real numbers, real locations, real authority. --> */}
              </h2>
            </div>
            <div className="flex items-center gap-4 bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex -space-x-3">
                {[1,2,3,4].map(i => (
                  <img 
                    key={i}
                    src={`https://picsum.photos/seed/${i+40}/64/64`}
                    alt="User"
                    className="w-12 h-12 rounded-full border-2 border-white"
                  />
                ))}
              </div>
              <div>
                <div className="flex text-yellow-400 mb-1">
                  {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 fill-current" />)}
                </div>
                <p className="text-xs font-bold text-slate-900">4.9/5 Average Rating</p>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah Jenkins",
                role: "CEO at TechFlow",
                text: "The 'So That' methodology changed my business. We didn't just get a new system; we got our freedom back.",
                img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&h=200&auto=format&fit=crop"
              },
              {
                name: "David Chen",
                role: "Founder, Growth Lab",
                text: "I was skeptical at first, but the results were undeniable within 14 days. This is the gold standard for landing pages.",
                img: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&h=200&auto=format&fit=crop"
              },
              {
                name: "Elena Rodriguez",
                role: "Marketing Director",
                text: "The emotional impact of their transformation headline actually delivered. My team is 40% more efficient now.",
                img: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=200&h=200&auto=format&fit=crop"
              }
            ].map((testimonial, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between hover-lift">
                <div>
                  <div className="flex text-yellow-400 mb-6">
                    {[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-current" />)}
                  </div>
                  <p className="text-slate-700 italic mb-8 leading-relaxed">
                    "{testimonial.text}"
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <img src={testimonial.img} alt={testimonial.name} className="w-14 h-14 rounded-full object-cover shadow-md" />
                  <div>
                    <p className="font-bold text-slate-900">{testimonial.name}</p>
                    <p className="text-sm text-slate-500">{testimonial.role}</p>
                  </div>
                </div>
                {/* <!-- BLUEPRINT COMMENT: Testimonial cards should address specific benefits mentioned in your grid. --> */}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL NUDGE - SCARCITY CTA */}
      <section className="py-24 bg-indigo-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 p-24 opacity-10">
          <Rocket className="w-96 h-96 -rotate-12" />
        </div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-indigo-800/50 border border-indigo-700 rounded-full px-4 py-2 mb-8 animate-bounce">
            <Clock className="w-5 h-5 text-indigo-300" />
            <span className="text-sm font-bold tracking-wide">Takes only 2 minutes to apply</span>
          </div>
          
          <h2 className="text-4xl lg:text-6xl font-extrabold mb-8 leading-tight">
            Stop Settling for "Good Enough" and Start Achieving the Exceptional.
            {/* <!-- BLUEPRINT COMMENT: Final headline - Summarize the outcome one last time. --> */}
          </h2>
          
          <p className="text-xl text-indigo-100 mb-12 max-w-2xl mx-auto leading-relaxed">
            Due to our high-touch approach, we only accept 3 new projects each week. Claim your spot before the window closes.
            {/* <!-- BLUEPRINT COMMENT: Scarcity Message - Explain why they MUST act now (Real limit). --> */}
          </p>
          
          <div className="flex flex-col items-center gap-6">
            <button className="bg-white text-indigo-900 px-12 py-6 rounded-2xl text-2xl font-black hover:bg-indigo-50 transition-all hover-lift shadow-2xl shadow-black/20 flex items-center gap-3">
              Book Your Session <ArrowRight className="w-8 h-8" />
            </button>
            
            <p className="text-sm text-indigo-300 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" /> No credit card required. No-obligation call.
            </p>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-12 border-t border-slate-100 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2 opacity-50">
             <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white font-bold">B</div>
             <span className="font-bold">BLUEPRINT PRO</span>
          </div>
          <p className="text-slate-400 text-sm">
            © 2024 Your Company Name. All rights reserved. Transforming lives through precision strategy.
          </p>
          <div className="flex gap-6 text-slate-400 text-sm font-medium">
            <a href="#" className="hover:text-indigo-600">Privacy</a>
            <a href="#" className="hover:text-indigo-600">Terms</a>
            <a href="#" className="hover:text-indigo-600">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
